// =============  Data Table - (Start) ================= //

$(document).ready(function(){
    var print = $('#printable').DataTable({
    });

    var dashprint = $('#dashprint').DataTable({
    });
    var leadingCandidates = $('#leadingCandidates').DataTable({
    });

    var dtable = $('#defaultTable').DataTable({
    });

   
});


   